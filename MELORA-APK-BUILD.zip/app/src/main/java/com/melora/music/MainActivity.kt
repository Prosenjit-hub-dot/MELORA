package com.melora.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF09090B)
private val Card = Color(0xFF17171B)
private val Accent = Color(0xFFB78CFF)
private val TextMain = Color(0xFFF6F2FF)
private val TextMuted = Color(0xFFA7A1B5)

data class Song(val title: String, val artist: String, val mood: String)

val demoSongs = listOf(
    Song("Midnight Drive", "MELORA Originals", "Night"),
    Song("Golden Hour", "Nova", "Chill"),
    Song("Electric Heart", "Luna Ray", "Energy"),
    Song("Afterglow", "Ari Vale", "Dreamy"),
    Song("Ocean Eyes", "The Waves", "Calm")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MeloraApp() }
    }
}

@Composable
fun MeloraApp() {
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Song?>(demoSongs.first()) }
    var playing by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Card, primary = Accent,
            onBackground = TextMain, onSurface = TextMain
        )
    ) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101014)) {
                    val labels = listOf("Home", "Search", "Library")
                    val icons = listOf(Icons.Default.Home, Icons.Default.Search, Icons.Default.LibraryMusic)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icons[i], contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                when (tab) {
                    0 -> HomeScreen(selected, onSelect = { selected = it; playing = true })
                    1 -> SearchScreen { selected = it; playing = true }
                    2 -> LibraryScreen()
                }
                selected?.let { PlayerBar(it, playing) { playing = !playing } }
            }
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("MELORA", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = TextMain)
            Text("Your sound. Your mood.", color = TextMuted, fontSize = 13.sp)
        }
        Box(Modifier.size(42.dp).clip(CircleShape).background(Accent), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, contentDescription = "Profile", tint = Bg)
        }
    }
}

@Composable
fun HomeScreen(selected: Song?, onSelect: (Song) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 100.dp)) {
        item { Header() }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Made for you", color = Accent, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Discover your next favorite sound.", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    Button(
                        onClick = { onSelect(demoSongs.random()) },
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Start a vibe")
                    }
                }
            }
        }
        item { Text("Quick picks", Modifier.padding(20.dp, 24.dp, 20.dp, 10.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        items(demoSongs) { SongRow(it, it == selected, onSelect) }
    }
}

@Composable
fun SongRow(song: Song, active: Boolean, onSelect: (Song) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onSelect(song) }.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(if (active) Accent else Color(0xFF24242A)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, null, tint = if (active) Bg else TextMain)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, fontWeight = FontWeight.SemiBold)
            Text(song.artist, color = TextMuted, fontSize = 13.sp)
        }
        Text(song.mood, color = Accent, fontSize = 12.sp)
    }
}

@Composable
fun SearchScreen(onSelect: (Song) -> Unit) {
    var query by remember { mutableStateOf("") }
    val results = demoSongs.filter { query.isBlank() || it.title.contains(query, true) || it.artist.contains(query, true) }
    Column(Modifier.fillMaxSize()) {
        Text("Search", Modifier.padding(20.dp, 24.dp, 20.dp, 12.dp), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Songs, artists, moods...") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true
        )
        Spacer(Modifier.height(16.dp))
        LazyColumn(contentPadding = PaddingValues(bottom = 100.dp)) {
            items(results) { SongRow(it, false, onSelect) }
        }
    }
}

@Composable
fun LibraryScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Your Library", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        LibraryCard(Icons.Default.Favorite, "Liked Songs", "Your personal favorites")
        LibraryCard(Icons.Default.QueueMusic, "Playlists", "Create and organize your vibes")
        LibraryCard(Icons.Default.History, "Recently Played", "Pick up where you left off")
        LibraryCard(Icons.Default.Download, "Offline Music", "Available for offline playback")
    }
}

@Composable
fun LibraryCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 7.dp), colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = TextMuted, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun PlayerBar(song: Song, playing: Boolean, onPlay: () -> Unit) {
    Surface(Modifier.fillMaxWidth(), color = Color(0xFF1C1824), tonalElevation = 8.dp) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(Accent), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.MusicNote, null, tint = Bg)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, fontWeight = FontWeight.SemiBold)
                Text(song.artist, color = TextMuted, fontSize = 12.sp)
            }
            IconButton(onClick = onPlay) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null) }
            IconButton(onClick = {}) { Icon(Icons.Default.SkipNext, null) }
        }
    }
}
